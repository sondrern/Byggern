#include "button.h"
#include "can.h"
#include "MCP2515.h"

volatile char *ext_adc = (char *) 0x1400;
uint8_t adc_read(int mux){

	*ext_adc = mux;
	while(PINB & (1<<PINB3)){}
	return *ext_adc;
}

void mem_init(void){
	MCUCR |= (1<<SRE);
	SFIOR |= (1<<XMM2);
}

void buttons_init(void){
	DDRB &= ~(1 << DDB0);
	DDRB &= ~(1 << DDB1);
	DDRB &= ~(1 << DDB2);
	DDRB &= ~(1<<DDB3);
	PORTB |= (1 << PB0);
	
}

char joystick(){
	uint8_t a = adc_read(5);
	int b = (a-123)*0.758;
	printf("y = %i %% \n ", b);
	if(a>130){
		printf("y = Up \n ");
	}
	else if (a<120){
		printf("y = Down \n ");
	}
	else{
		
		printf("y = Neutral \n ");
	}

	

	a = adc_read(4);
	b = (a-123)*0.758;
	printf("x = %i %% \n ", b);
	if(a>140){
		printf("x = RIGHT \n ");
	}
	else if (a<115){
		printf("x = LEFT \n ");
	}
	else{
		
		printf("x = Neutral \n ");
	}
}

void buttonsend(struct data button){
		uint8_t a = adc_read(5);

		int b = (a-123)*0.758;
		char X= '0';
		char Y='0';
		

		if(a>140){
		
			Y='U';
			
		}
		else if (a<115){
		
			Y='D';
		}
		else{
			
		
			Y='N';
		}

	

		a = adc_read(4);
	
		b = (a-123)*0.758;
		
		if(a>140){
		
			X='D';
		}
		else if (a<115){
		
			X='U';
		}
		else{
			
		
			X='N';
		}
		
		
		
		
		button.id=1;
		button.length=1;
		
		
		if(X=='N' && Y=='N'){
			button.data[0]=0b00000000;
			}
		else if(X=='N' && Y=='U'){
		button.data[0]=0b00000001;
		}
		else if(X=='N'&& Y=='D'){
		button.data[0]= 0b00000010;
		}
		else if(X=='U'&& Y=='N'){
			button.data[0]= 0b00000011;
		}
		else if (X=='U' && Y=='U'){
			button.data[0]= 0b00000100;
		}
		else if (X=='U' && Y=='D'){
			button.data[0]= 0b00000101;
		}
		else if(X=='D' && Y=='N'){
			button.data[0]= 0b00000110;
		}
		else if(X=='D' && Y=='U'){
			button.data[0]=0b00000111;
		}
		else if(X=='D' && Y=='D'){
			button.data[0]= 0b00001000;
		}
		
		if(PINB & (1<<PINB1)){
			button.data[0] |= (1<<6);
		}
		
		if(PINB & (1<<PINB2)){
			button.data[0] |= (1<<7);
		}
		

	can_message_send(button);
	
}
