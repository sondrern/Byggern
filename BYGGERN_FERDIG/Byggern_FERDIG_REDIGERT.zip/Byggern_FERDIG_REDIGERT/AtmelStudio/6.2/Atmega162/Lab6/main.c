
#include "uart.h"
#include "can.h"
#include "spi.h"
#include "MCP2515.h"
#include "button.h"
#include "oled.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
	
	USART_Init();  //
   
can_init();
mem_init();

buttons_init();
oled_init();

mainmenu();
printf("After menu \n");

can_init();
mem_init();
buttons_init();
struct data a;

   for(;;){   
	  buttonsend(a);
	
		_delay_ms(10);
		
   }
   return 0;
}
	
	
	




