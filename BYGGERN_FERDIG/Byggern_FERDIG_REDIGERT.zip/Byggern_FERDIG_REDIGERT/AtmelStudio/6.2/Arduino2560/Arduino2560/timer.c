#include "timer.h"
#include "uart.h"
void pwm_period(float period_ms){
	

	TCCR3A  |=  (1 << WGM41);
	TCCR3B  |=  (1 << WGM42)
	|   (1 << WGM43);

	
	
	TCCR3A  |=  (1 << COM4A1);

	TCCR3B  |=  (1 << CS41)
	|   (1 << CS40);


	ICR3 = F_CPU/64/1000 * period_ms;
	

	DDRE    |=  (1 << DDE3);

}

void pwm_width(double poswidth_ms){
	if(poswidth_ms>2.1){
		poswidth_ms=2.1;
	}
	else if(poswidth_ms<0.9){
		poswidth_ms=0.9;
	}
	OCR3A = F_CPU/64/1000 * poswidth_ms;
}