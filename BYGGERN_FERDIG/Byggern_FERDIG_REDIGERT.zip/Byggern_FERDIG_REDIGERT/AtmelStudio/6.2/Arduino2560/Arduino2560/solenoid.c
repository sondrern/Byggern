#include <avr/io.h>
#include "solenoid.h"
#define solenoidPin PC4

void solenoid_init(void){
	DDRC |= (1<<solenoidPin);
	solenoid_off();
}	

void solenoid_off(void){
	PORTC |= (1<<solenoidPin);
}

void solenoid_on(void){
	PORTC &= ~(1<<solenoidPin);
}
