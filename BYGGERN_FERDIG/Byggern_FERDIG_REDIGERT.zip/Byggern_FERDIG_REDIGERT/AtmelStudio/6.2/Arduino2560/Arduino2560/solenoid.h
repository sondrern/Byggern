

#ifndef SOLENOID_H_
#define SOLENOID_H_


void solenoid_init(void);
void solenoid_on(void);
void solenoid_off(void);



#endif 