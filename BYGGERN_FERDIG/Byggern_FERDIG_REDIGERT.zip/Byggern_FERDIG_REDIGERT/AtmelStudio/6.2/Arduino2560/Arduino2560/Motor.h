#pragma once
#include <stdint.h>


int position;

void PID_init(void);
uint16_t readencoder(void);
void reset_toogle(void);
void direction_toogle(void);
void controlmotor_dir(int dir);
void controlmotor(int dir);

void to_target(int target);
#define EN PH4
#define F_CPU 16000000UL

