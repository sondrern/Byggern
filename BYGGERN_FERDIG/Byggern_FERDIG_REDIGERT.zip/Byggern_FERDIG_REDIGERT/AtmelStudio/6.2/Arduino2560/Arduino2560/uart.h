
#pragma once
#define F_CPU 16000000UL
#ifndef UART_H_
#define UART_H_




#include <avr/io.h>
#include <avr/interrupt.h>





void USART1_SendByte(uint8_t u8Data);
uint8_t USART1_ReceiveByte();
void USART1_Init(void);

void USART_SendByte(uint8_t u8Data);
uint8_t USART_ReceiveByte();
void USART_Init(void);


void USART3_Init(void);
uint8_t USART3_ReceiveByte();
void USART3_SendByte(uint8_t u8Data);



#endif /* UART_H_ */