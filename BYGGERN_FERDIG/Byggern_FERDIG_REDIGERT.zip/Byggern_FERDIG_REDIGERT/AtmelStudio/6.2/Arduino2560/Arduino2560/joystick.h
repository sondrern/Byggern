#pragma once
#include <stdint.h>
#include "MCP2515.h"
#define F_CPU 16000000UL
struct direction{
	int x;
	int y;
	
	
};
struct direction setbutton(uint8_t buttons );
double servo(double angle);

int data_ready;
int modeflag;