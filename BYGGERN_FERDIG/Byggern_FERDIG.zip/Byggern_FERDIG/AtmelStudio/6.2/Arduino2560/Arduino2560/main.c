
#include "uart.h"
#include "can.h"
#include "spi.h"
#include "MCP2515.h"
#include "timer.h"
#include "joystick.h"
#include "ir.h"
//#include "game.h"
#include "TWI_Master.h"
#include "Motor.h"
#include "solenoid.h"
//#include "Controller.h"
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>



#ifdef XBOX
//#define XBOX







int main()		
{			
	USART_Init();
	printf("Main\n");
	
	
	TWI_Master_Initialise();
	uint8_t controller;
	
	controll_init();
	
	printf("Main\n");
	
	
	
	
	while(1){
		
		
	
		
	

	
	controll();


	
	
	
}
return 0;
}









#else

int main(){
	TWI_Master_Initialise();
	can_controll_init();
	controll_init();
	uint8_t controller;
	
	modeflag=1;
	
	

	while (1)
	{
		
		if(modeflag==1){
			//printf("can_controll()");
			can_controll();
		}
		else{
			
			controll();
		}
		
	}
	
	
	return 0;
}



#endif