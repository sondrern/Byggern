#include "Controller.h"
#include "uart.h"
#include "solenoid.h"
#include "can.h"
#include "timer.h"
#include "joystick.h"
#include "ir.h"
#include <avr/io.h>
#define F_CPU 16000000UL
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>


void controll_init(void){
	TWI_Master_Initialise();
	sei();
	solenoid_init();
	USART1_Init();
	USART_Init();
	USART3_Init();
	pwm_period(20);
	PID_init();
	InitADC();
	
	pos=readencoder();
	printf("pos=%i\n",pos);
	_delay_ms(100);
	//init_interrupt();
	controller=0;
	angle=0.9;
	pwm_width(0.9);
	target =0;
	pre_pos= 0;
	score= 0;
	game_on = 1;
	_delay_ms(1000);
}

void controll(void)
{		
	
	controller = USART1_ReceiveByte();
	
		//pwm_width(1.5);
		pos=readencoder();
		//printf("pos=%i\n",pos);
	
		if(controller==1)
		{	
			solenoid_on();
			_delay_ms(40);
			solenoid_off();
			if (!game_on)
			{
				USART3_SendByte(0b00000010);
				game_on=1;
			}
			//printf("A button pushed\n");
		}
		if(controller==2)
		{
			//printf("B button pressed\n");
			modeflag=1;
			can_controll_init();
			return;
		}
		if(controller==4)
		{
			angle=angle + 0.1;
			if(angle>2.1){
				angle=2.1;
		}	//printf("right\n");
			pwm_width(angle);
			_delay_ms(30);
			return angle;
		}
		 if(controller==8)
		{
			angle=angle - 0.1;
			if(angle<0.9)
			{
				angle=0.9;
			}
			//printf("left\n");
			pwm_width(angle);
			_delay_ms(50);
			return angle;
		}
		
		if(controller==128)
		{	//printf("l1maks\n");
			target=pos+500;
			if(target>=MAX|| pos>=MAX)
			{
				target=MAX;
				
			}
			to_target(target);
		}
		if(controller==32)
		{	//printf("r1maks\n");
			target=pos-500;
			if (target<MIN||pos<=MIN)
			{
				target=MIN;
			
			}
			
			to_target(target);
		}
		/*pos=readencoder();
		int error=pos-target;
		if (error<=150 && error >=-150){
			printf("to target from main pos = %i\n",pos);
			to_target(target);
		}
		*/
		pre_pos=target;
		check();
		controller=0;
		if(digfilter())
		{	
			if(game_on)
			{
			score=score +1;
			USART3_SendByte(0b00000001);
			game_on=0;
					printf("goal, Score= %i\n",score);
				}
			
		
		}
}
		
	
void check(void){
	int change= readencoder()-pre_pos;
	//printf("cHANGE =%i\n",change);
	if(change >100 || change<-100){
		if(pre_pos>=MAX){
			pre_pos=MAX;
		}
		else if(pre_pos<=MIN) {
			pre_pos=MIN;
			}
		to_target(pre_pos);
		}
	}




void can_controll(void)
{		
	
		struct data a= can_data_receive();
		
		//printf("button = %i \n", a.data[0]);
		controller=0;
		
		if((a.data[0]>>6 & 1)==1){
			controller=2;
			a.data[0] &= ~(1<<6);
		}
		else if((a.data[0]>>7 & 1)==1){
			controller=1;
			a.data[0] &= ~(1<<7);
		}
		
		struct direction joypos=setbutton(a.data[0]);
		
		//printf("Button = %i \n", a.data[0]);
		if(joypos.x==1){
			controller=32;
		}
		else if(joypos.x==2){
			controller=128;
		}
		else if(joypos.y==1){
			controller=8;
		}
		else if(joypos.y==2){
			controller=4;
		}
		
		
		
		//pwm_width(1.5);
		pos=readencoder();
		//printf("pos=%i\n",pos);
	
		if(controller==1)
		{	
			solenoid_on();
			_delay_ms(40);
			solenoid_off();
			if (!game_on)
			{
				USART3_SendByte(0b00000010);
				game_on=1;
			}
			printf("A button pushed\n");
		}
		if(controller==2)
		{
			printf("B button pressed\n");
			// handle shift mode xbox can
			modeflag=2;
		}
		if(controller==4)
		{
			angle=angle + 0.1;
			if(angle>2.1){
				angle=2.1;
		}	//printf("right\n");
			pwm_width(angle);
			_delay_ms(30);
			//return angle;
		}
		 if(controller==8)
		{
			angle=angle - 0.1;
			if(angle<0.9)
			{
				angle=0.9;
			}
			//printf("left\n");
			pwm_width(angle);
			_delay_ms(50);
			//return angle;
		}
		
		if(controller==128)
		{	//printf("l1maks\n");
			target=pos+500;
			if(target>=MAX|| pos>=MAX)
			{
				target=MAX;
				
			}
			to_target(target);
		}
		if(controller==32)
		{	//printf("r1maks\n");
			target=pos-500;
			if (target<MIN||pos<=MIN)
			{
				target=MIN;
			
			}
			
			to_target(target);
		}
		/*pos=readencoder();
		int error=pos-target;
		if (error<=150 && error >=-150){
			printf("to target from main pos = %i\n",pos);
			to_target(target);
		}
		*/
		pre_pos=target;
		check();
		controller=0;
		if(digfilter())
		{	
			if(game_on)
			{
			score=score +1;
			USART3_SendByte(0b00000001);
			game_on=0;
					printf("goal, Score= %i\n",score);
				}
			
		
		}
	//_delay_ms(10);		
}
	
	
	
	void can_controll_init(void){
		TWI_Master_Initialise();
		sei();
		solenoid_init();
		
		USART1_Init();
		USART_Init();
		USART3_Init();
		can_init();
		pwm_period(20);
		PID_init();
		InitADC();
		
		pos=readencoder();
		printf("pos=%i\n",pos);
		_delay_ms(100);
		//init_interrupt();
		controller=0;
		angle=0.9;
		pwm_width(0.9);
		target =0;
		pre_pos= 0;
		score= 0;
		game_on = 1;
		_delay_ms(1000);
	}	
	
/*void init_interrupt(void){
	DDRE &= ~(1<<PE5);		// Set PE5 as input (Using for interupt INT5)
	//PORTE = 1<<PE5;		// Enable PE5 pull-up resistor

	EIMSK |= (1<<INT5);					// Enable INT0
	EICRB = (1<<ISC50) | (1<<ISC51);
	//sei();
}
*/

/*ISR(INT5_vect)
{
	
	controller = USART1_ReceiveByte();
	//USART1_SendByte(a);
	//a=a-'0';
	//printf("Atmega Received = %i \n",controller);
	
}
*/




