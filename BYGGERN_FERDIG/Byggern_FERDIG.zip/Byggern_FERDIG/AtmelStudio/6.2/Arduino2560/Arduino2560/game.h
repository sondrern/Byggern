#pragma once
int flag;
#include "joystick.h"
int score(int pr_score);