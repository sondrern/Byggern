
#include "uart.h"
#include "can.h"
#include "spi.h"
#include "MCP2515.h"
#include <stdio.h>
#include <stdlib.h>

int main(){
	
	USART_Init();  //
   
can_init();
   for(;;){   
	   
		struct data message;
		message.id = 59;
		message.length = 2;
		message.data[0] = 12;
		message.data[1] = 13;
		
		can_message_send(message);
		for (int i = 0; i<message.length; i++){
			printf("Message [%i] = %i \n", i, message.data[i]);
		}
		
		struct data received=can_data_receive();
		for (int i = 0; i<received.length; i++){
			printf("Received [%i] = %i \n", i, received.data[i]);
		}
		
		_delay_ms(10000);
		
   }
   return 0;
}
	
	
	

