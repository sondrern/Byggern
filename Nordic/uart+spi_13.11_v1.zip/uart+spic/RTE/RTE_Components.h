
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'ble_app_uart_pca10040_s132' 
 * Target:  'nrf52832_xxaa' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "nrf.h"


#endif /* RTE_COMPONENTS_H */
