#include<stdint.h>
void SPI_init();
void SPI_high();
void SPI_low();

void SPI_send(uint8_t cData);

char SPI_receive();