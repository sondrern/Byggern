#include "SPIcpp.h"
#include <avr/pgmspace.h>




void SPI_init(){

	DDRB |= (1<<DDB5) | (1<<DDB3) | (1<<DDB2) ;
	DDRB &=~(1<<DDB4);
	PORTB |= (1<<DDB4);


	SPI_high();
	
	
	
	
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
}

void SPI_send(uint8_t cData){
	
	SPDR = cData;
	//SPDR=0b01000010;

	while(!(SPSR & (1<<SPIF))){};
}


char SPI_receive(){
	SPDR=0b00000000;
	//SPI_send(0xff);
	while(!(SPSR & (1<<SPIF))){};
	return SPDR;
}

void SPI_high(){
	(PORTB |= (1<<PB2));
}
void SPI_low(){
	(PORTB &= ~(1<<PB2));
}

