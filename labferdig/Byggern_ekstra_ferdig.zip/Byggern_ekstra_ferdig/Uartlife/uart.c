#include "uart.h"

#include <stdlib.h>
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

// Define baud rate

#define F_CPU 16000000UL
#define USART_BAUDRATE 38400
#define BAUD_PRESCALE (((F_CPU / (USART_BAUDRATE * 16UL))) - 1)


void USART_SendByte(uint8_t u8Data){
	
	// VENT TIL SIST BYTE ER SENDT
	while((UCSR0A &(1<<UDRE0)) == 0);
	
	//SEND
	UDR0 = u8Data;
}



uint8_t USART_ReceiveByte(){
	while((UCSR0A &(1<<RXC0)) == 0);
	return UDR0;
}

void USART_Init(void){

	UBRR1L = BAUD_PRESCALE;
	UBRR1H = (BAUD_PRESCALE >> 8);
	UCSR1B = ((1<<TXEN0)|(1<<RXEN0) );
	UCSR1C = (3<<UCSZ00);
	fdevopen(&USART_SendByte, &USART_ReceiveByte);
}


