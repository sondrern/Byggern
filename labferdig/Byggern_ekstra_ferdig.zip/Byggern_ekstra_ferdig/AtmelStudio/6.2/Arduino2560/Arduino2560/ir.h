#pragma once
#include <stdio.h>
#define knekkfrekvens 50
void InitADC();
uint16_t ReadADC(uint8_t ch);
int digfilter();