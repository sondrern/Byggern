#include "joystick.h"
#include "can.h"
#include "timer.h"
#include "Motor.h"
#include <util/delay.h>

struct direction setbutton(uint8_t buttons ){
	struct direction a;
		if(buttons==0b00000000){
			a.x= 0;
			a.y=0;
			//printf("X=N \n Y=N\n");
			}
		else if(buttons== 0b00000001){
			a.x= 0;
			a.y=2;
			//printf("X=N \n Y=U\n");
		}
		else if(buttons==0b00000010){
				a.x= 0;
				a.y=1;
			//printf("X=N \n Y=D\n");
		}
		else if(buttons== 0b00000011){
				a.x= 2;
				a.y=0;
			//printf("X=L \n Y=N\n");
		}
		else if (buttons== 0b00000100){
				a.x= 2;
				a.y=2;
			//printf("X=L \n Y= U\n");
		}
			
		else if (buttons== 0b00000101){
				a.x= 2;
				a.y=1;
				//printf("X=L \n Y= D\n");
			}
		else if (buttons== 0b00000110){
				a.x= 1;
				a.y=0;
			//printf("X=R \n Y=N\n");
		}
		else if(buttons==0b00000111){
				a.x= 1;
				a.y=2;
			//printf("X=R \n Y=U\n");
		}
		else if(buttons== 0b00001000){
				a.x= 1;
				a.y=1;
			//printf("X=R \n Y=D\n");
		}
		else{
		//printf("failed in setbutton");
		}
		
	return a;
	
	
	
}
double servo(double angle){
	struct data button;
	struct direction b;
	button= can_data_receive();
	
	b=setbutton(button.data[0]);
		
	if(b.x==1){
		angle=angle + 0.3;
		if(angle>2.1){
			angle=2.1;
		}
		pwm_width(angle);
		_delay_ms(100);
		return angle;
		}
	else if(b.x==2){
		angle=angle - 0.1;
		if(angle<0.9){
			angle=0.9;
		}
		pwm_width(angle);
		_delay_ms(100);
		return angle;
	}
	
	if(b.y==1){
		controlmotor(1);
	}
	else if(b.y==2){
		controlmotor(0);
	}
	
	
	return angle;
	
}

