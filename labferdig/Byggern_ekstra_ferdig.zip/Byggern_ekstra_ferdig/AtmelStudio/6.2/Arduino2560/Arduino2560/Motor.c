#include "Motor.h"
#include "TWI_Master.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#define F_CPU 16000000UL
void PID_init(void){
	uint8_t messageBuf[3];
	
	DDRH |=(1<<DDH1) |(1<<DDH4) | (1<<DDH6) | (1<<DDH5)|(1<<DDH3);//INPUT
	DDRK= 0x00; //INPUT
	PORTK=0xFF;	//PULLUP MJ2
	PORTH |= (1<<PH4)|(1<<PH1) ;//EN & DIR
	//(PORTH &= ~(1<<PH1));
	
	//sett intialpunkt
	messageBuf[0] = 0b01010000;
	messageBuf[1]=0b00000000;
	messageBuf[2]=0b01111111;
	TWI_Start_Transceiver_With_Data( messageBuf,3);
	_delay_ms(1000);
	PORTH&=~(1<<PH4);
	_delay_ms(500);
	reset_toogle();
	position= readencoder();
	printf("Position RESET=%i\n",position);
	
}
uint16_t readencoder(void){
	
		uint8_t MSB=0;
		uint8_t LSB=0;
		uint16_t encoder=0;
		PORTH &=~(1<<PH5);// SET OE LOW
		PORTH &=~(1<<PH3);//SET SEL LOW
		
		_delay_us(20);
		
		MSB= PINK;			//READ MSB
		
		//printf("MSB=%02x\n",MSB);
		PORTH |= (1<<SEL);	//SET SEL HIGH
		
		_delay_us(20);
		
		LSB=PINK;			//READ LSB
		//reset_toogle();
		
		//printf("LSB=%02x\n",LSB);
		//reset_toogle();
		PORTH|=(1<<OE);		//SET OE HIGH
		
		/*
		for(int i=0; i<8; i++){
			if((MSB>>i & 1) == 1){
				printf("1");
			}
			else{
				printf("0");
			}
			
		}
		*/
		//printf("\n");
		encoder= ((MSB<<8)|LSB);	// SET POS = MSB+LSB
		//encoder = LSB;
		//printf("encoder=%i\n",encoder);
		return encoder;
		}

void direction_toogle(void){
	uint16_t pos;
	int counter=0;
	while(1)
{
	if(counter%2)
	{
		
		controlmotor_dir(0);
		
	}
	else
	{
		controlmotor_dir(1);
		
		
		
	}
	pos= readencoder();
	printf("Pos=%i\n",pos);
	counter++;
	_delay_ms(2000);
 }
}
void reset_toogle(void){
	PORTH &=~ (1<<PH6);
	_delay_ms(1);
	PORTH |= (1<<PH6);
	
	
	
}

void controlmotor_dir(int dir)
{
	//reset_toogle();
	if(dir==1){
		PORTH &=~(1<<PH1);
		}
	else if(dir==0){
		PORTH|= (1<<PH1);
		}
		
	PORTH |= (1<<EN);
	_delay_ms(750);
	PORTH &= ~(1<<EN);
	
	//int pos=readencoder();
	//printf("Posistion = %i \n", pos);	
		
}


void to_target(int target){
	uint8_t messageBuf[3];
	messageBuf[0] = 0b01010000;
	messageBuf[1]=0b00000000;
	messageBuf[2]=0b00001111;
	TWI_Start_Transceiver_With_Data( messageBuf,3);
	//PORTH |= (1<<EN);
	int pos;
	signed int error=0;
	
	while(1){
		TWI_Start_Transceiver_With_Data( messageBuf,3);
		pos=readencoder();

	
		//printf("pos=%i\n",pos);
		error=pos-target;
		//printf("POS=%i\n",readencoder());
		//printf("error = %i \n", error);
		if((error <=100 && error >= -100)){
			PORTH &= ~(1<<EN);
			break;
		}
		else if(error < 1){
			//printf("SKIFTER >1\n");
			PORTH |= (1<<EN);
			PORTH &= ~(1<<PH1);
			pos=readencoder();
			//printf("pos=%i\n",pos);
		}
		else if(error > 1){
			
			//printf("SKIFTER<1\n");
			PORTH |= (1<<EN);
			PORTH |= (1<<PH1);
			pos=readencoder();
			//printf("pos=%i\n",pos);
			
		}
		
		/*if(error > 700 || error < -700){
			messageBuf[2]=0b01111;
		} 
		else if(error > 200 || error < -200){
			messageBuf[2]=0b10111111;
			
			
		}
		else{*/
			messageBuf[2]=0b11111111;

		//}
	
		
	}
	
	
	
}
