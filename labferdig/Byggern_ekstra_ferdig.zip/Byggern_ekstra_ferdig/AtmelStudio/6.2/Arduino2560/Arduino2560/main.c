
#include "uart.h"
#include "can.h"
#include "spi.h"
#include "MCP2515.h"
#include "timer.h"
#include "joystick.h"
#include "ir.h"
#include "game.h"
#include "TWI_Master.h"
#include "Motor.h"
#include "solenoid.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#define F_CPU 16000000UL










int main()		
{			
	USART_Init();
	printf("Main\n");
	
	
	TWI_Master_Initialise();
	uint8_t controller;
	
	controll_init();
	
	printf("Main\n");
	
	
	
	
	while(1){
		
		
	
		
	

	
	controll();


	
	
	
}
return 0;
}












