#pragma once
#include "uart.h"
#define F_CPU 16000000UL
#define MAX 8500
#define MIN 0
#include <util/delay.h>
int controller;
float angle;
int target;
uint16_t pos;
uint16_t pre_pos;
int score;
int game_on; 
int compare=1;
void controll_init(void);
void controll(void);
void check(void);








