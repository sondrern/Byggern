#include "game.h"
#include "ir.h"
int score(int pr_score){
	

	if(digfilter()){
		if(!flag){
			
		pr_score=pr_score +1;
		flag=1;
		}
	}
	else{
	flag=0;
	}
	return pr_score;
		
	}
	


