
#include "uart.h"
#include "can.h"
#include "spi.h"
#include "MCP2515.h"
#include "timer.h"
#include "joystick.h"
#include "ir.h"
#include "game.h"
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>

int main(){
	
	USART_Init();  //
	can_init();
	
	
	
	double i=0.9;
	double z=0.00;
	int j=0;
		float a= 20.000;
		pwm_period(a);
		pwm_width(1.2);

		int mal=0;
   while(1){   
	   
	   mal=score(mal);
	  printf("M�L=%d\n",mal);
	   
	   
	   
		i=servo(i);
		z=i;
		z=z*10;
		j=z;
		printf("i=%d\n",j);
	  	_delay_ms(100);
	
	
   }
   return 0;
}

