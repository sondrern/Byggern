#include "timer.h"
#include "uart.h"
void pwm_period(float period_ms){
	

	TCCR4A  |=  (1 << WGM41);
	TCCR4B  |=  (1 << WGM42)
	|   (1 << WGM43);

	
	
	TCCR4A  |=  (1 << COM4A1);

	TCCR4B  |=  (1 << CS41)
	|   (1 << CS40);


	ICR4 = F_CPU/64/1000 * period_ms;


	DDRH    |=  (1 << DDH3);

}

void pwm_width(double poswidth_ms){
	if(poswidth_ms>2.1){
		poswidth_ms=2.1;
	}
	else if(poswidth_ms<0.9){
		poswidth_ms=0.9;
	}
	OCR4A = F_CPU/64/1000 * poswidth_ms;
}