#pragma once

#include <avr/io.h>

void pwm_period(float period_ms);

void pwm_width(double poswidth_ms);