#pragma once
#include <stdint.h>
#include "MCP2515.h"
struct direction{
	int x;
	int y;
	
	
};
struct direction setbutton(uint8_t buttons );
double servo(double angle);

