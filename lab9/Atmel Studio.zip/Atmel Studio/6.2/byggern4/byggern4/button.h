#include "uart.h"

uint8_t adc_read(int mux);
void mem_init(void);

void buttons_init(void);

char joystick();
